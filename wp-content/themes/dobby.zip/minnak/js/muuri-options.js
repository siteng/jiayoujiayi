jQuery(document).ready(function( $ ){
  /* MASONARY GRID */
  var grid = new Muuri('.grid');
});