<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package MiNNaK
 */

?>
		<footer id="colophon" class="site-footer">
		<div id="site-info" class="site-info">
			<?php minnak_site_copyright(); ?>
			<?php minnak_credit(); ?>
		</div>
		</footer>
	</main>
</div>

<?php wp_footer(); ?>

</body>
		<script>
		  var oSpan = document.getElementById("daojishi");
		  function tow(n) {
			return n >= 0 && n < 10 ? '0' + n : '' + n;
		  }
		  function getDate() {
			var oDate = new Date();
			var oldTime = oDate.getTime();
			var newDate = new Date('2034/6/7 08:00:00');
			var newTime = newDate.getTime();
			var second = Math.floor((newTime - oldTime) / 1000);//未来时间距离现在的秒数
			var day = Math.floor(second / 86400);//整数部分代表的是天；一天有24*60*60=86400秒 ；
			second = second % 86400;//余数代表剩下的秒数；
			var hour = Math.floor(second / 3600);//整数部分代表小时；
			second %= 3600; //余数代表 剩下的秒数；
			var minute = Math.floor(second / 60);
			second %= 60;
			var str = tow(day) + '<span class="time">天</span>'
				+ tow(hour) + '<span class="time">小时</span>';
			oSpan.innerHTML = str;
		  }
		  getDate();
		  setInterval(getDate, 1000);
		</script>
</html>
