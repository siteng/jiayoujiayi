<?php

define( 'DOBBY_VERSION', '1.0' );

require_once( get_template_directory() . '/inc/core.php');
require_once( get_template_directory() . '/inc/smtp.php');
require_once( get_template_directory() . '/inc/global.php');
require_once( get_template_directory() . '/inc/images.php');
require_once( get_template_directory() . '/inc/widget.php');
require_once( get_template_directory() . '/inc/single.php');
require_once( get_template_directory() . '/inc/comments.php');
require_once( get_template_directory() . '/inc/navwalker.php');
require_once( get_template_directory() . '/inc/shortcode.php');
//avatar头像本地化
function my_avatar($avatar) {
$tmp = strpos($avatar, 'http');
$g = substr($avatar, $tmp, strpos($avatar, "'", $tmp) - $tmp);
$tmp = strpos($g, 'avatar/') + 7;
$f = substr($g, $tmp, strpos($g, "?", $tmp) - $tmp);
//$w = get_bloginfo('wpurl');
$w = 'https://cdn.sjiayi.com';
$e = ABSPATH .'avatar/'. $f .'.jpg';
$t = 1209600; //设定14天，单位秒
if ( !is_file($e) || (time() - filemtime($e)) > $t ) { //当头像不存在或超过14天更新
copy(htmlspecialchars_decode($g), $e);
} else $avatar = strtr($avatar, array($g => $w.'/avatar/'.$f.'.jpg'));
if (filesize($e) < 500) copy($w.'/avatar/default.jpg', $e);
return $avatar;
}
add_filter('get_avatar', 'my_avatar');

//移除前台adminbar的样式
add_action( 'wp_enqueue_scripts', 'fanly_remove_block_library_css', 100 );
function fanly_remove_block_library_css() {
	wp_dequeue_style( 'wp-block-library' );
}
//网站运行时间函数
function time2string($second){
	$day = floor($second/(3600*24));
	$second = $second%(3600*24);
	$hour = floor($second/3600);
//	$second = $second%3600;
//	$minute = floor($second/60);
//	$second = $second%60;
	return $day.'天'.$hour.'小时';
}